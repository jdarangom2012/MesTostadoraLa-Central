# =============================================================
# sql_writer.py — Ejecución de Stored Procedures en SQL Server
# =============================================================

from typing import Optional
import pyodbc
from config import SQL_CONN, SP_TUESTE, SP_ENFRIAMIENTO


class SQLWriter:

    def __init__(self):
        self.conn: Optional[pyodbc.Connection] = None

    # ── Conexión ─────────────────────────────────────────────
    def conectar(self) -> bool:
        try:
            self.conn = pyodbc.connect(SQL_CONN, autocommit=False)
            return True
        except pyodbc.Error as e:
            raise ConnectionError(f"Error conectando a SQL Server: {e}")

    def desconectar(self):
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass

    def _asegurar_conexion(self):
        try:
            if self.conn:
                self.conn.cursor().execute("SELECT 1")
                return
        except Exception:
            pass
        self.conectar()

    # ── Ejecución genérica de SP ─────────────────────────────
    def _ejecutar_sp(self, sp: str, params: tuple) -> int:
        """
        Ejecuta el SP y retorna el ID insertado (SCOPE_IDENTITY).
        Lanza pyodbc.Error si algo falla (el caller hace rollback).
        """
        self._asegurar_conexion()
        cur = self.conn.cursor()
        cur.execute(sp, params)
        row = cur.fetchone()
        self.conn.commit()
        return int(row[0]) if row else -1

    # ── Tueste ───────────────────────────────────────────────
    def insertar_tueste(self, d: dict) -> int:
        """Llama a sp_InsertarCurvaTueste con los datos del bloque tueste."""
        sql = (
            f"EXEC {SP_TUESTE} "
            "@Orden=?, @ClienteId=?, @ClienteNombre=?, @PerfilTueste=?, "
            "@PesoCafVerde=?, @FechaIniOrden=?, @HoraIniOrden=?, "
            "@ConsumoGas=?, @ConsumoKwh=?, @PesoCafTostado=?, "
            "@TempDesh=?, @TiempoDesh_seg=?, "
            "@TempRecu=?, @TiempoRecu_seg=?, "
            "@Temp1Crack=?, @Tiempo1Crack_seg=?, "
            "@TempFinCurva=?, @TiempoFinCurva_seg=?, "
            "@FechaFinOrden=?, @HoraFinOrden=?, "
            "@TiempoTueste_seg=?, @TiempoEnfr_seg=?"
        )
        params = (
            d["Orden"],          d["ClienteId"],       d["ClienteNombre"],
            d["PerfilTueste"],   d["PesoCafVerde"],    d["FechaIniOrden"],
            d["HoraIniOrden"],   d["ConsumoGas"],      d["ConsumoKwh"],
            d["PesoCafTostado"], d["TempDesh"],         d["TiempoDesh_seg"],
            d["TempRecu"],       d["TiempoRecu_seg"],   d["Temp1Crack"],
            d["Tiempo1Crack_seg"], d["TempFinCurva"],  d["TiempoFinCurva_seg"],
            d["FechaFinOrden"],  d["HoraFinOrden"],
            d["TiempoTueste_seg"], d["TiempoEnfr_seg"],
        )
        return self._ejecutar_sp(sql, params)

    # ── Enfriamiento ─────────────────────────────────────────
    def insertar_enfriamiento(self, d: dict) -> int:
        """Llama a sp_InsertarCurvaEnfriamiento con los datos del bloque enfriamiento."""
        sql = (
            f"EXEC {SP_ENFRIAMIENTO} "
            "@Orden=?, @ClienteId=?, @ClienteNombre=?, @PerfilTueste=?, "
            "@PesoCafVerde=?, @FechaIniOrden=?, @HoraIniOrden=?, "
            "@ConsumoGas=?, @ConsumoKwh=?, @PesoCafTostado=?, "
            "@TempDesh=?, @TiempoDesh_seg=?, "
            "@TempRecu=?, @TiempoRecu_seg=?, "
            "@Temp1Crack=?, @Tiempo1Crack_seg=?, "
            "@TempFinCurva=?, @TiempoFinCurva_seg=?, "
            "@FechaFinOrden=?, @HoraFinOrden=?, "
            "@TiempoTueste_seg=?, @TiempoEnfr_seg=?"
        )
        params = (
            d["Orden"],          d["ClienteId"],       d["ClienteNombre"],
            d["PerfilTueste"],   d["PesoCafVerde"],    d["FechaIniOrden"],
            d["HoraIniOrden"],   d["ConsumoGas"],      d["ConsumoKwh"],
            d["PesoCafTostado"], d["TempDesh"],         d["TiempoDesh_seg"],
            d["TempRecu"],       d["TiempoRecu_seg"],   d["Temp1Crack"],
            d["Tiempo1Crack_seg"], d["TempFinCurva"],  d["TiempoFinCurva_seg"],
            d["FechaFinOrden"],  d["HoraFinOrden"],
            d["TiempoTueste_seg"], d["TiempoEnfr_seg"],
        )
        return self._ejecutar_sp(sql, params)
