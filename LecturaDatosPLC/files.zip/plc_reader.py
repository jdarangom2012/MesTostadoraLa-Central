# =============================================================
# plc_reader.py — Lectura Modbus TCP del M221
# Direcciones exactas según REPORTE_PLC.xlsx
# =============================================================

from typing import Optional
from pymodbus.client import ModbusTcpClient
from pymodbus.exceptions import ModbusException
from plc_types import (
    bcd16_a_segundos, bcd32_a_fecha, bcd32_a_hora,
    regs_a_udint, regs_a_real, regs_a_string
)
from config import PLC_HOST, PLC_PORT, PLC_UNIT_ID, COIL_TRIGGER


# =============================================================
# MAPA DE BLOQUES DE MEMORIA
# Cada bloque se lee de un tirón para minimizar peticiones Modbus.
# Direcciones %MW → Holding Register (misma numeración en M221).
# =============================================================

# ── TUESTE: %MW500 al %MW537 ─────────────────────────────────
# Leemos 38 words de golpe (500 a 537 inclusive)
TUESTE_START = 500
TUESTE_COUNT = 38   # 537 - 500 + 1

# ── ENFRIAMIENTO: %MW600 al %MW637 ───────────────────────────
ENFR_START = 600
ENFR_COUNT = 38     # 637 - 600 + 1


def _offset(base: int, addr: int) -> int:
    """Índice dentro del bloque leído."""
    return addr - base


def _parsear_bloque_tueste(regs: list) -> dict:
    """
    Parsea los 38 words del bloque de Tueste (%MW500-537).
    Retorna un dict con todos los campos listos para el SP.
    """
    b = TUESTE_START

    # %MD500 = UDINT 32 bit (2 words: %MW500 + %MW501)
    orden = regs_a_udint(regs, _offset(b, 500))

    # %MW502 = UINT cliente ID
    cliente_id = regs[_offset(b, 502)]

    # %MW503-512 = STRING 20 char (10 words)
    cliente_nombre = regs_a_string(regs, _offset(b, 503), 10)

    # %MW513 = UINT perfil tueste
    perfil_tueste = regs[_offset(b, 513)]

    # %MF514 = REAL 32 bit (2 words: %MW514 + %MW515)
    peso_cv = regs_a_real(regs, _offset(b, 514))

    # %MD516 = BCD 32 bit → fecha ini (2 words: %MW516 + %MW517)
    fecha_ini_dword = regs_a_udint(regs, _offset(b, 516))
    fecha_ini = bcd32_a_fecha(fecha_ini_dword)

    # %MD518 = BCD 32 bit → hora ini (2 words: %MW518 + %MW519)
    hora_ini_dword = regs_a_udint(regs, _offset(b, 518))
    hora_ini = bcd32_a_hora(hora_ini_dword)

    # %MW520 = UINT consumo gas
    consumo_gas = regs[_offset(b, 520)]

    # %MW521 = UINT consumo kWh
    consumo_kwh = regs[_offset(b, 521)]

    # %MF522 = REAL 32 bit → peso café tostado (2 words: %MW522 + %MW523)
    peso_ct = regs_a_real(regs, _offset(b, 522))

    # %MW524 = UINT temperatura deshidratación
    temp_desh = regs[_offset(b, 524)]

    # %MW525 = BCD 16 bit → tiempo deshidratación en segundos
    tiem_desh_seg = bcd16_a_segundos(regs[_offset(b, 525)])

    # %MW526 = UINT temperatura recuperación
    temp_recu = regs[_offset(b, 526)]

    # %MW527 = BCD 16 bit → tiempo recuperación
    tiem_recu_seg = bcd16_a_segundos(regs[_offset(b, 527)])

    # %MW528 = UINT temperatura 1er crack
    temp_1crk = regs[_offset(b, 528)]

    # %MW529 = BCD 16 bit → tiempo 1er crack
    tiem_1crk_seg = bcd16_a_segundos(regs[_offset(b, 529)])

    # %MW530 = UINT temperatura fin curva
    temp_fin_curva = regs[_offset(b, 530)]

    # %MW531 = BCD 16 bit → tiempo total curva de tueste
    tiem_fin_curva_seg = bcd16_a_segundos(regs[_offset(b, 531)])

    # %MD532 = BCD 32 bit → fecha fin (2 words)
    fecha_fin_dword = regs_a_udint(regs, _offset(b, 532))
    fecha_fin = bcd32_a_fecha(fecha_fin_dword)

    # %MD534 = BCD 32 bit → hora fin (2 words)
    hora_fin_dword = regs_a_udint(regs, _offset(b, 534))
    hora_fin = bcd32_a_hora(hora_fin_dword)

    # %MW536 = BCD 16 bit → tiempo total tueste
    tiem_tueste_seg = bcd16_a_segundos(regs[_offset(b, 536)])

    # %MW537 = BCD 16 bit → tiempo total enfriamiento
    tiem_enfr_seg = bcd16_a_segundos(regs[_offset(b, 537)])

    return {
        "Orden":              orden,
        "ClienteId":          cliente_id,
        "ClienteNombre":      cliente_nombre,
        "PerfilTueste":       perfil_tueste,
        "PesoCafVerde":       peso_cv,
        "FechaIniOrden":      fecha_ini,
        "HoraIniOrden":       hora_ini,
        "ConsumoGas":         consumo_gas,
        "ConsumoKwh":         consumo_kwh,
        "PesoCafTostado":     peso_ct,
        "TempDesh":           temp_desh,
        "TiempoDesh_seg":     tiem_desh_seg,
        "TempRecu":           temp_recu,
        "TiempoRecu_seg":     tiem_recu_seg,
        "Temp1Crack":         temp_1crk,
        "Tiempo1Crack_seg":   tiem_1crk_seg,
        "TempFinCurva":       temp_fin_curva,
        "TiempoFinCurva_seg": tiem_fin_curva_seg,
        "FechaFinOrden":      fecha_fin,
        "HoraFinOrden":       hora_fin,
        "TiempoTueste_seg":   tiem_tueste_seg,
        "TiempoEnfr_seg":     tiem_enfr_seg,
    }


def _parsear_bloque_enfriamiento(regs: list) -> dict:
    """
    Parsea los 38 words del bloque de Enfriamiento (%MW600-637).
    Misma estructura que tueste, base 600.
    """
    b = ENFR_START

    orden          = regs_a_udint(regs, _offset(b, 600))
    cliente_id     = regs[_offset(b, 602)]
    cliente_nombre = regs_a_string(regs, _offset(b, 603), 10)
    perfil_tueste  = regs[_offset(b, 613)]
    peso_cv        = regs_a_real(regs, _offset(b, 614))

    fecha_ini_dword = regs_a_udint(regs, _offset(b, 616))
    fecha_ini = bcd32_a_fecha(fecha_ini_dword)
    hora_ini_dword = regs_a_udint(regs, _offset(b, 618))
    hora_ini = bcd32_a_hora(hora_ini_dword)

    consumo_gas    = regs[_offset(b, 620)]
    consumo_kwh    = regs[_offset(b, 621)]
    peso_ct        = regs_a_real(regs, _offset(b, 622))

    temp_desh      = regs[_offset(b, 624)]
    tiem_desh_seg  = bcd16_a_segundos(regs[_offset(b, 625)])
    temp_recu      = regs[_offset(b, 626)]
    tiem_recu_seg  = bcd16_a_segundos(regs[_offset(b, 627)])
    temp_1crk      = regs[_offset(b, 628)]
    tiem_1crk_seg  = bcd16_a_segundos(regs[_offset(b, 629)])
    temp_fin_curva = regs[_offset(b, 630)]
    tiem_fin_curva_seg = bcd16_a_segundos(regs[_offset(b, 631)])

    fecha_fin_dword = regs_a_udint(regs, _offset(b, 632))
    fecha_fin = bcd32_a_fecha(fecha_fin_dword)
    hora_fin_dword  = regs_a_udint(regs, _offset(b, 634))
    hora_fin = bcd32_a_hora(hora_fin_dword)

    tiem_tueste_seg = bcd16_a_segundos(regs[_offset(b, 636)])
    tiem_enfr_seg   = bcd16_a_segundos(regs[_offset(b, 637)])

    return {
        "Orden":              orden,
        "ClienteId":          cliente_id,
        "ClienteNombre":      cliente_nombre,
        "PerfilTueste":       perfil_tueste,
        "PesoCafVerde":       peso_cv,
        "FechaIniOrden":      fecha_ini,
        "HoraIniOrden":       hora_ini,
        "ConsumoGas":         consumo_gas,
        "ConsumoKwh":         consumo_kwh,
        "PesoCafTostado":     peso_ct,
        "TempDesh":           temp_desh,
        "TiempoDesh_seg":     tiem_desh_seg,
        "TempRecu":           temp_recu,
        "TiempoRecu_seg":     tiem_recu_seg,
        "Temp1Crack":         temp_1crk,
        "Tiempo1Crack_seg":   tiem_1crk_seg,
        "TempFinCurva":       temp_fin_curva,
        "TiempoFinCurva_seg": tiem_fin_curva_seg,
        "FechaFinOrden":      fecha_fin,
        "HoraFinOrden":       hora_fin,
        "TiempoTueste_seg":   tiem_tueste_seg,
        "TiempoEnfr_seg":     tiem_enfr_seg,
    }


# =============================================================
# CLASE PRINCIPAL
# =============================================================
class PLCReader:

    def __init__(self):
        self.client: Optional[ModbusTcpClient] = None

    # ── Conexión ─────────────────────────────────────────────
    def conectar(self) -> bool:
        try:
            self.client = ModbusTcpClient(
                host=PLC_HOST, port=PLC_PORT, timeout=5
            )
            ok = self.client.connect()
            return ok
        except Exception as e:
            raise ConnectionError(f"Error conectando al PLC {PLC_HOST}: {e}")

    def desconectar(self):
        if self.client:
            try:
                self.client.close()
            except Exception:
                pass

    def _asegurar_conexion(self):
        if not self.client or not self.client.is_socket_open():
            self.conectar()

    # ── Coil %M93 ────────────────────────────────────────────
    def leer_trigger(self) -> Optional[bool]:
        """Lee el coil %M93. Retorna True/False o None si falla."""
        self._asegurar_conexion()
        try:
            r = self.client.read_coils(COIL_TRIGGER, 1, slave=PLC_UNIT_ID)
            if r.isError():
                return None
            return bool(r.bits[0])
        except ModbusException as e:
            raise IOError(f"Error leyendo %M{COIL_TRIGGER}: {e}")

    def resetear_trigger(self):
        """Escribe False en %M93 para indicar al PLC que ya se procesó."""
        self._asegurar_conexion()
        try:
            self.client.write_coil(COIL_TRIGGER, False, slave=PLC_UNIT_ID)
        except ModbusException as e:
            raise IOError(f"Error reseteando %M{COIL_TRIGGER}: {e}")

    # ── Lectura de bloques ────────────────────────────────────
    def _leer_bloque(self, start: int, count: int) -> list:
        """Lee 'count' Holding Registers desde 'start'. Lanza IOError si falla."""
        self._asegurar_conexion()
        r = self.client.read_holding_registers(start, count, slave=PLC_UNIT_ID)
        if r.isError():
            raise IOError(f"Error leyendo HR addr={start} count={count}: {r}")
        return r.registers

    def leer_datos_tueste(self) -> dict:
        """Lee y parsea el bloque de tueste (%MW500-537)."""
        regs = self._leer_bloque(TUESTE_START, TUESTE_COUNT)
        return _parsear_bloque_tueste(regs)

    def leer_datos_enfriamiento(self) -> dict:
        """Lee y parsea el bloque de enfriamiento (%MW600-637)."""
        regs = self._leer_bloque(ENFR_START, ENFR_COUNT)
        return _parsear_bloque_enfriamiento(regs)
