# =============================================================
# plc_service.py — Servicio Windows
# Lee %M93 cada 2 seg → si = 1 lee PLC → guarda en SQL → log
#
# INSTALAR como servicio:
#   python plc_service.py install
#   python plc_service.py start
#
# DESINSTALAR:
#   python plc_service.py stop
#   python plc_service.py remove
#
# PROBAR sin instalar (modo consola):
#   python plc_service.py debug
# =============================================================

import sys
import time
import traceback

import win32serviceutil
import win32service
import win32event
import servicemanager

from config import POLL_SEG
from logger_setup import crear_logger, log_registro_insertado, log_error_insercion
from plc_reader import PLCReader
from sql_writer import SQLWriter


# =============================================================
# LÓGICA DE NEGOCIO
# =============================================================
def procesar_ciclo(lector: PLCReader, escritor: SQLWriter, log):
    """
    Un ciclo completo:
    1. Lee %M93
    2. Si = 1 → lee ambos bloques de registros
    3. Inserta en SQL Server via SP
    4. Registra en log
    5. Resetea %M93 a 0
    """
    try:
        trigger = lector.leer_trigger()
    except IOError as e:
        log.warning(f"No se pudo leer %M93: {e}")
        return

    if trigger is None:
        log.warning("Respuesta nula al leer %M93 — PLC sin respuesta")
        return

    if not trigger:
        # Normal: el PLC aún no activó la señal
        return

    # ── %M93 = 1 → procesar ──────────────────────────────────
    log.info("▶ %M93 = 1 detectado — iniciando lectura de registros")

    # ── Bloque TUESTE (%MW500-537) ────────────────────────────
    try:
        datos_tueste = lector.leer_datos_tueste()
    except Exception as e:
        log.error(f"Error leyendo bloque TUESTE del PLC: {e}")
        datos_tueste = None

    # ── Bloque ENFRIAMIENTO (%MW600-637) ─────────────────────
    try:
        datos_enfr = lector.leer_datos_enfriamiento()
    except Exception as e:
        log.error(f"Error leyendo bloque ENFRIAMIENTO del PLC: {e}")
        datos_enfr = None

    # ── Insertar TUESTE en SQL ────────────────────────────────
    if datos_tueste:
        try:
            id_ins = escritor.insertar_tueste(datos_tueste)
            log_registro_insertado(
                log,
                tabla=f"tblCurvasTueste (ID={id_ins})",
                datos=datos_tueste
            )
        except Exception as e:
            log_error_insercion(
                log,
                tabla="tblCurvasTueste",
                error=str(e),
                datos=datos_tueste
            )

    # ── Insertar ENFRIAMIENTO en SQL ──────────────────────────
    if datos_enfr:
        try:
            id_ins = escritor.insertar_enfriamiento(datos_enfr)
            log_registro_insertado(
                log,
                tabla=f"tblCurvasEnfriamiento (ID={id_ins})",
                datos=datos_enfr
            )
        except Exception as e:
            log_error_insercion(
                log,
                tabla="tblCurvasEnfriamiento",
                error=str(e),
                datos=datos_enfr
            )

    # ── Resetear %M93 ────────────────────────────────────────
    try:
        lector.resetear_trigger()
        log.info("◀ %M93 reseteado a 0 — listo para próximo ciclo")
    except IOError as e:
        log.warning(f"No se pudo resetear %M93: {e}")


# =============================================================
# SERVICIO WINDOWS
# =============================================================
class PLCWindowsService(win32serviceutil.ServiceFramework):

    _svc_name_         = "PLCCurvasTueste"
    _svc_display_name_ = "PLC Curvas Tueste — Modicon M221"
    _svc_description_  = (
        "Lee registros de curvas de tueste desde el PLC Modicon M221 "
        "via Modbus TCP/IP y los almacena en SQL Server."
    )

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self._stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._running = True
        self.log = crear_logger("PLCService")

    def SvcStop(self):
        """Llamado por Windows cuando se detiene el servicio."""
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self._stop_event)
        self._running = False
        self.log.info("Servicio detenido por Windows.")

    def SvcDoRun(self):
        """Bucle principal del servicio."""
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, "")
        )
        self.log.info(
            f"═══ Servicio PLCCurvasTueste iniciado ═══  "
            f"Poll cada {POLL_SEG}s | Trigger=%M93"
        )
        self._ejecutar_loop()

    def _ejecutar_loop(self):
        lector  = PLCReader()
        escritor = SQLWriter()

        # Conexiones iniciales
        try:
            lector.conectar()
            self.log.info("✔ Conectado al PLC")
        except Exception as e:
            self.log.error(f"Conexión inicial al PLC falló: {e}")

        try:
            escritor.conectar()
            self.log.info("✔ Conectado a SQL Server")
        except Exception as e:
            self.log.error(f"Conexión inicial a SQL Server falló: {e}")

        # Bucle principal
        while self._running:
            try:
                procesar_ciclo(lector, escritor, self.log)
            except Exception:
                self.log.error(
                    f"Error no controlado en ciclo:\n{traceback.format_exc()}"
                )

            # Espera POLL_SEG segundos, pero verificando el stop cada 0.5s
            for _ in range(int(POLL_SEG / 0.5)):
                if not self._running:
                    break
                time.sleep(0.5)

        lector.desconectar()
        escritor.desconectar()
        self.log.info("Servicio finalizado correctamente.")


# =============================================================
# MODO DEBUG (consola, sin instalar como servicio)
# =============================================================
def _modo_debug():
    """
    Corre el loop directamente en consola para pruebas.
    Ctrl+C para detener.
    """
    log = crear_logger("PLCDebug")
    log.info(f"Modo DEBUG — Poll %M93 cada {POLL_SEG}s — Ctrl+C para salir")

    lector   = PLCReader()
    escritor = SQLWriter()

    try:
        lector.conectar()
        log.info("✔ PLC conectado")
    except Exception as e:
        log.error(f"PLC: {e}")

    try:
        escritor.conectar()
        log.info("✔ SQL Server conectado")
    except Exception as e:
        log.error(f"SQL: {e}")

    try:
        while True:
            procesar_ciclo(lector, escritor, log)
            time.sleep(POLL_SEG)
    except KeyboardInterrupt:
        log.info("Detenido manualmente.")
    finally:
        lector.desconectar()
        escritor.desconectar()


# =============================================================
# ENTRY POINT
# =============================================================
if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "debug":
        _modo_debug()
    else:
        win32serviceutil.HandleCommandLine(PLCWindowsService)
